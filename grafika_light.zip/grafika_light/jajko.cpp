﻿#include <GL/freeglut.h>
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <chrono>

using namespace std;

bool jajko = true;
bool autoRotate = false;
bool mouseRotate = true;
bool mouseLeftDown = false;
bool controlObject = true;   // true = obracamy jajko, false = obracamy kamerę
float camYaw = 0.0f;         // poziomo
float camPitch = 0.0f;       // pionowo
float camDistance = 25.0f;   // oddalenie od obiektu
float zoomSpeed = 1.0f;
int lastMouseX = 0;
int lastMouseY = 0;
float rotX = 0.0f;
float rotY = 0.0f;
float rotZ = 0.0f;
int N = 30;        // gęstość siatki
float points[200][200][3];   // tablica punktów jajka. max rozmiar
float normals[200][200][3];
float colors[200][200][3]; // R,G,B każdego punktu
auto lastTime = chrono::high_resolution_clock::now();
// ======== GLOBALNE USTAWIENIA OŚWIETLENIA ========
GLfloat light0_pos[] = { 5.0,  5.0, 10.0, 1.0 };  // reflektor czerwony
GLfloat light1_pos[] = { -5.0, -5.0, 10.0, 1.0 };  // reflektor niebieski


int mode = 3;            // 1 - punkty, 2 - siatka, 3 - trójkąty

// =======================================
// OŚ X,Y,Z
// =======================================
void drawAxes()
{
    glLineWidth(2.0f);
    glBegin(GL_LINES);

    // Oś X – czerwona
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(-5.0f, 0.0f, 0.0f);
    glVertex3f(5.0f, 0.0f, 0.0f);

    // Oś Y – zielona
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(0.0f, -5.0f, 0.0f);
    glVertex3f(0.0f, 5.0f, 0.0f);

    // Oś Z – niebieska
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(0.0f, 0.0f, -5.0f);
    glVertex3f(0.0f, 0.0f, 5.0f);

    glEnd();
}

// =======================================
// GENEROWANIE PUNKTÓW
// =======================================
void GeneratePoints()
{
    for (int i = 0; i < N; i++)
    {
        float u = (float)i / (N - 1);

        for (int j = 0; j < N; j++)
        {
            float v = (float)j / (N - 1);

            float x = (-90 * pow(u, 5) + 225 * pow(u, 4) - 270 * pow(u, 3) +
                180 * pow(u, 2) - 45 * u) * cos(M_PI * v);

            float y = 160 * pow(u, 4) - 320 * pow(u, 3) + 160 * pow(u, 2);

            float z = (-90 * pow(u, 5) + 225 * pow(u, 4) - 270 * pow(u, 3) +
                180 * pow(u, 2) - 45 * u) * sin(M_PI * v);

            points[i][j][0] = x;
            points[i][j][1] = y - 5.0f;
            points[i][j][2] = z;
        }
    }



    // --- sklejenie biegunów ---
    for (int j = 0; j < N; j++)
    {
        points[0][j][0] = points[0][0][0];
        points[0][j][1] = points[0][0][1];
        points[0][j][2] = points[0][0][2];

        points[N - 1][j][0] = points[N - 1][0][0];
        points[N - 1][j][1] = points[N - 1][0][1];
        points[N - 1][j][2] = points[N - 1][0][2];
    }

    // --- liczenie normalnych ---
    for (int i = 0; i < N; i++)
    {
        float u = (float)i / (N - 1);

        for (int j = 0; j < N; j++)
        {
            float v = (float)j / (N - 1);

            // pochodne cząstkowe x(u,v), y(u,v), z(u,v)
            float du = (-450 * pow(u, 4) + 900 * pow(u, 3) - 810 * pow(u, 2) + 360 * u - 45);
            float dv = M_PI * (-90 * pow(u, 5) + 225 * pow(u, 4) - 270 * pow(u, 3) + 180 * pow(u, 2) - 45 * u);

            float dx_du = du * cos(M_PI * v);
            float dy_du = (640 * pow(u, 3) - 960 * pow(u, 2) + 320 * u);
            float dz_du = du * sin(M_PI * v);

            float dx_dv = dv * (-sin(M_PI * v));
            float dy_dv = 0.0f;
            float dz_dv = dv * cos(M_PI * v);

            // wektor normalny = du × dv
            float nx = dy_du * dz_dv - dz_du * dy_dv;
            float ny = dz_du * dx_dv - dx_du * dz_dv;
            float nz = dx_du * dy_dv - dy_du * dx_dv;

            // odwrócenie! (to kluczowe)
            float len = sqrt(nx * nx + ny * ny + nz * nz);
            normals[i][j][0] = nx / len;
            normals[i][j][1] = ny / len;
            normals[i][j][2] = nz / len;
        }
    }

    // sklejenie biegunów normalnych
    for (int j = 0; j < N; j++)
    {
        normals[0][j][0] = 0.0f;
        normals[0][j][1] = -1.0f;
        normals[0][j][2] = 0.0f;

        normals[N - 1][j][0] = 0.0f;
        normals[N - 1][j][1] = 1.0f;
        normals[N - 1][j][2] = 0.0f;
    }
}


void GenerateColors()
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            colors[i][j][0] = (float)rand() / RAND_MAX; // R
            colors[i][j][1] = (float)rand() / RAND_MAX; // G
            colors[i][j][2] = (float)rand() / RAND_MAX; // B
        }
    }
}

// =======================================
// PUNKTY
// =======================================
void DrawPoints()
{
    glBegin(GL_POINTS);
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            glVertex3fv(points[i][j]);
    glEnd();
}

// =======================================
// SIATKA
// =======================================
void DrawWireframe()
{
    glBegin(GL_LINES);

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            int j2 = (j + 1) % N;
            glVertex3fv(points[i][j]);
            glVertex3fv(points[i][j2]);
        }
    }

    for (int j = 0; j < N; j++)
    {
        for (int i = 0; i < N - 1; i++)
        {
            glVertex3fv(points[i][j]);
            glVertex3fv(points[i + 1][j]);
        }
    }

    glEnd();
}

// =======================================
// TRÓJKĄTY
// =======================================
void DrawTriangles()
{
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    glColor3f(1.0f, 1.0f, 1.0f);   // cały model w białym kolorze

    for (int i = 0; i < N - 1; i++)
    {
        for (int j = 0; j < N; j++)
        {
            int j2 = (j + 1) % N;

            glBegin(GL_TRIANGLES);

            // wierzchołek 1
            glNormal3fv(normals[i][j]);
            glVertex3fv(points[i][j]);

            // wierzchołek 2
            glNormal3fv(normals[i + 1][j]);
            glVertex3fv(points[i + 1][j]);

            // wierzchołek 3
            glNormal3fv(normals[i][j2]);
            glVertex3fv(points[i][j2]);

            // drugi trójkąt
            glNormal3fv(normals[i + 1][j]);
            glVertex3fv(points[i + 1][j]);

            glNormal3fv(normals[i + 1][j2]);
            glVertex3fv(points[i + 1][j2]);

            glNormal3fv(normals[i][j2]);
            glVertex3fv(points[i][j2]);

            glEnd();


        }
    }
}

// =======================================
// KLAWIATURA
// =======================================
void Keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case '1': mode = 1; break;
    case '2': mode = 2; break;
    case '3': mode = 3; break;

    case '.':     // zwiększ N
        if (N < 100) {
            N++;
            GeneratePoints();
            GenerateColors();
            
        }
        break;

    case ',':     // zmniejsz N
        if (N > 3) {
            N--;
            GeneratePoints();
            GenerateColors();
            
        }
        break;
    case 'c':
        jajko = false;
        cout << "Teapot mode\n";
        break;
    case 'j':
        jajko = true;;
        cout << "Egg mode\n";
        break;

    case 'o':
        controlObject = true;
        cout << "Sterowanie: obiekt\n";
        break;

    case 'k':
        controlObject = false;
        cout << "Sterowanie: kamera\n";
        break;
    case '[':
        if (!autoRotate && !mouseRotate) {
            rotZ -= 5.0f;
        }
        break;
    case ']':
        if (!autoRotate && !mouseRotate) {
            rotZ += 5.0f;
        }
        break;
    case 'm':
        autoRotate = false;
        mouseRotate = false;
        cout << "Manual key rotation\n";
        break;

    case 'a':
        autoRotate = true;
        mouseRotate = false;
        cout << "Auto rotation\n";
        break;
    case 'n':
        autoRotate = false;
        mouseRotate = true;
        cout << "Manual mouse rotation\n";
        break;
    }
    glutPostRedisplay();
}
void SpecialKeys(int key, int x, int y)
{
    if (!autoRotate && !mouseRotate && controlObject) {
        switch (key)
        {
        case GLUT_KEY_UP:
            rotX += 5.0f;
            break;
        case GLUT_KEY_DOWN:
            rotX -= 5.0f;
            break;
        case GLUT_KEY_LEFT:
            rotY -= 5.0f;
            break;
        case GLUT_KEY_RIGHT:
            rotY += 5.0f;
            break;
        }
    }
    else if (!autoRotate && !mouseRotate && !controlObject)
    {
        // sterowanie KAMERĄ
        switch (key)
        {
        case GLUT_KEY_UP:    camPitch += 3.0f; break;
        case GLUT_KEY_DOWN:  camPitch -= 3.0f; break;
        case GLUT_KEY_LEFT:  camYaw -= 3.0f;  break;
        case GLUT_KEY_RIGHT: camYaw += 3.0f;  break;
        }
        if (camPitch > 89.0f) camPitch = 89.0f;
        if (camPitch < -89.0f) camPitch = -89.0f;
    }
    glutPostRedisplay();
}

void MouseButton(int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseLeftDown = true;
            lastMouseX = x;
            lastMouseY = y;
        }
        else if (state == GLUT_UP)
        {
            mouseLeftDown = false;
        }
    }

    if (button == 3)   // scroll UP
    {
        camDistance -= zoomSpeed;
        if (camDistance < 0.1f) camDistance = 0.1f;  // minimalna odległość
        glutPostRedisplay();
    }
    else if (button == 4)  // scroll DOWN
    {
        camDistance += zoomSpeed;
        if (camDistance > 100.0f) camDistance = 100.0f;  // maks zoom
        glutPostRedisplay();
    }
}
void MouseMotion(int x, int y)
{
    if (mouseRotate && mouseLeftDown)
    {
        int dx = x - lastMouseX;
        int dy = y - lastMouseY;

        if (controlObject)
        {
            // obracamy obiekt
            rotY += dx * 0.5f;
            rotX += dy * 0.5f;
        }
        else
        {
            // obracamy kamerę
            camYaw += dx * 0.4f;
            camPitch += dy * 0.4f;

            if (camPitch > 89.0f) camPitch = 89.0f;
            if (camPitch < -89.0f) camPitch = -89.0f;
        }

        lastMouseX = x;
        lastMouseY = y;

        glutPostRedisplay();
    }
}
// Zamienia wektor offset (w przestrzeni kamery: x-right, y-up, z-forward negative) na koordynaty świata
void CameraOffsetToWorld(float offsetX, float offsetY, float offsetZ, float eyeX, float eyeY, float eyeZ,
    float yawDeg, float pitchDeg, float outPos[3])
{
    // konwersja kątów na radiany
    float yaw = yawDeg * (float)M_PI / 180.0f;
    float pitch = pitchDeg * (float)M_PI / 180.0f;

    // budujemy macierz rotacji z yaw (Y) i pitch (X)
    // punkt w lokalnej przestrzeni kamery (right, up, forward)
    // forward w lokalnej to (0,0,-1). Tutaj używamy konwencji podobnej do UpdateCameraPosition.
    // Najpierw wektor lokalny
    float lx = offsetX;
    float ly = offsetY;
    float lz = offsetZ;

    // Rzucamy rotację pitch (x) i yaw (y)
    // obrót pitch: obrót wokół osi X
    float cosy = cosf(yaw), siny = sinf(yaw);
    float cosp = cosf(pitch), sinp = sinf(pitch);

    // Najpierw obracamy wokół X (pitch), potem wokół Y (yaw)
    // rotX:
    float rx = lx;
    float ry = ly * cosp - lz * sinp;
    float rz = ly * sinp + lz * cosp;

    // rotY:
    float wx = rx * cosy + rz * siny;
    float wy = ry;
    float wz = -rx * siny + rz * cosy;

    outPos[0] = eyeX + wx;
    outPos[1] = eyeY + wy;
    outPos[2] = eyeZ + wz;
}

void Idle()
{
    if (autoRotate)
    {
        auto currentTime = chrono::high_resolution_clock::now();
        float deltaTime = chrono::duration<float>(currentTime - lastTime).count(); // sekundy
        lastTime = currentTime;

        rotY += 20.0f * deltaTime; // 20 stopni na sekundę
        rotX += 8.0f * deltaTime;
        rotZ += 20.0f * deltaTime;

        if (rotY > 360) rotY -= 360;
        if (rotX > 360) rotX -= 360;
        if (rotZ > 360) rotZ -= 360;

        glutPostRedisplay();
    }
}

void SetupMaterial()
{
    GLfloat mat_ambient[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess = 20.0;

    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT, GL_SHININESS, mat_shininess);
}

void SetupLight0() //światło czerwone
{
    GLfloat ambient[] = { 0.05f, 0.0f, 0.0f, 1.0f };
    GLfloat diffuse[] = { 0.6f, 0.0f, 0.0f, 1.0f };
    GLfloat specular[] = { 0.4f, 0.1f, 0.1f, 1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_pos);

    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.05);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.001);

    glEnable(GL_LIGHT0);
}

void SetupLight1() //światło niebieskie
{
    GLfloat ambient[] = { 0.0f, 0.0f, 0.05f, 1.0f };
    GLfloat diffuse[] = { 0.0f, 0.0f, 0.6f, 1.0f };
    GLfloat specular[] = { 0.1f, 0.1f, 0.4f, 1.0f };

    glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_pos);

    glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0);
    glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.05);
    glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.001);

    glEnable(GL_LIGHT1);
}

void SetupLightingSystem()
{
    glEnable(GL_LIGHTING);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);

    SetupLight0();
    SetupLight1();
    SetupMaterial();
}

// =======================================
// RYSOWANIE
// =======================================
void RenderScene()
{
    glEnable(GL_LIGHTING);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();

    float camX = camDistance * cos(camPitch * M_PI / 180.0f) * sin(camYaw * M_PI / 180.0f);
    float camY = camDistance * sin(camPitch * M_PI / 180.0f);
    float camZ = camDistance * cos(camPitch * M_PI / 180.0f) * cos(camYaw * M_PI / 180.0f);

    gluLookAt(camX, camY, camZ,
        0.0, 0.0, 0.0,
        0.0, 1.0, 0.0);

  //  glPushMatrix();

    // Obliczamy pozycję kamery (eye)
    float eyeX = camDistance * cos(camPitch * M_PI / 180.0f) * sin(camYaw * M_PI / 180.0f);
    float eyeY = camDistance * sin(camPitch * M_PI / 180.0f);
    float eyeZ = camDistance * cos(camPitch * M_PI / 180.0f) * cos(camYaw * M_PI / 180.0f);

    // Jeżeli sterujemy obiektem — światła są stałe w przestrzeni świata:
    if (controlObject)
    {
        glLightfv(GL_LIGHT0, GL_POSITION, light0_pos);
        glLightfv(GL_LIGHT1, GL_POSITION, light1_pos);
    }
    else
    {
        // Jeżeli sterujemy KAMERĄ — ustawiamy światła względem kamery
        // offsety w lokalnej przestrzeni kamery: (right, up, forward)
        float pos0[3], pos1[3];
        // reflektor 0: lekko w prawo i w górę z przodu kamery
        CameraOffsetToWorld(3.0f, 2.5f, -6.0f, eyeX, eyeY, eyeZ, camYaw, camPitch, pos0);
        CameraOffsetToWorld(-3.0f, 2.5f, -6.0f, eyeX, eyeY, eyeZ, camYaw, camPitch, pos1);

        GLfloat lp0[4] = { pos0[0], pos0[1], pos0[2], 1.0f };
        GLfloat lp1[4] = { pos1[0], pos1[1], pos1[2], 1.0f };

        glLightfv(GL_LIGHT0, GL_POSITION, lp0);
        glLightfv(GL_LIGHT1, GL_POSITION, lp1);
    }

   // glPopMatrix();
    
   

  //  glPushMatrix();
    drawAxes();
 //   glPopMatrix();

    glPushMatrix();

    if (controlObject)
    {
        glRotatef(rotX, 1, 0, 0);
        glRotatef(rotY, 0, 1, 0);
        glRotatef(rotZ, 0, 0, 1);
    }

    glColor3f(1.0, 0.8, 0.0);

    if (jajko) {
        if (mode == 1) DrawPoints();
        if (mode == 2) DrawWireframe();
        if (mode == 3) DrawTriangles();
    }
    else {
        if (mode == 1) {
            glColor3f(1.0f, 1.0f, 1.0f);
            glutWireTeapot(5.0);
        }
        if (mode == 2) {
            glColor3f(1.0f, 1.0f, 1.0f);
            glutWireTeapot(5.0);
        }
        if (mode == 3) {
            glColor3f(1.0f, 1.0f, 1.0f);
            glutSolidTeapot(5.0);
        }
    }

    glPopMatrix();
    glFlush();
}

void MyInit()
{
    glEnable(GL_NORMALIZE);            // automatyczna normalizacja wektorów normalnych
    glEnable(GL_COLOR_MATERIAL);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE); // oświetlenie obu stron
    glFrontFace(GL_CCW);
    glClearColor(0.0, 0.0, 0.0, 1.0);

    glPointSize(3.0);
    glEnable(GL_DEPTH_TEST);

    GeneratePoints();
    GenerateColors();
    SetupLightingSystem();
}

void ChangeSize(GLsizei horizontal, GLsizei vertical)
{
    if (vertical == 0) vertical = 1;
    GLfloat aspect = (GLfloat)horizontal / (GLfloat)vertical;

    glViewport(0, 0, horizontal, vertical);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(70, aspect, 0.01, 200.0);

    glTranslatef(0.0, 0.0, 0.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv)
{

    cout << "==============================" << endl;
    cout << "Aby sterowanie dzialalo okno z grafika musi byc otwarte i zfokusowane" << endl;
    cout << "Naciskac tylko jeden klawisz na raz" << endl;
    cout << "Klawisz \"1\" - tryb punktow" << endl;
    cout << "Klawisz \"2\" - tryb lini/siatki" << endl;
    cout << "Klawisz \"3\" - tryb trojkatow" << endl;
    cout << "Klawisz \",\" - zmniejszanie ilosci punktow" << endl;
    cout << "Klawisz \".\" - zwiekszenie ilosci punktow" << endl;
    cout << "Klawisze \"left\" / \"right\" - obracaja obiekt po osi X" << endl;
    cout << "Klawisze \"up\" / \"down\" - obracaja obiekt po osi Y" << endl;
    cout << "Klawisze \"[\" / \"]\" - obracaja obiekt po osi Z" << endl;
    cout << "Klawisz \"a\" - wlacza automatyczne obracanie" << endl;
    cout << "Klawisz \"m\" - wlacza manualne obracanie za pomoca klawiszy" << endl;
    cout << "Klawisz \"n\" - wlacza manualne obracanie za pomoca myszy" << endl;
    cout << "Oby uzywac obracania mysza nalezy trzymac lewy przycisk i krecic mysza" << endl;
    cout << "Klawisz \"k\"- przelacza tryb obracania na kamere" << endl;
    cout << "Klawisz \"o\"- przelacza tryb obracania na obiekt" << endl;
    cout << "W obu trybach sterowanie dziala prawie tak samo, w trybie kamery nie ma obracania po osi Z" << endl;
    cout << "Klawisz \"j\" - zmienia model na jajko" << endl;
    cout << "Klawisz \"c\" - zmienia model na czajnik" << endl;
    cout << "W modelu czajnik dzialaja tryb lini i trojkatow (wypelnienie na niebiesko), tryb ponktow wyswietli linie" << endl;
    cout << "W modelu czajnik zwiększanie N nic nie zmienia" << endl;
    cout << "==============================" << endl;
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 800);
    glutCreateWindow("Egg Model");

    MyInit();

    glutDisplayFunc(RenderScene);
    glutReshapeFunc(ChangeSize);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialKeys);

    glutIdleFunc(Idle);

    glutMouseFunc(MouseButton);
    glutMotionFunc(MouseMotion);

    glutMainLoop();
    return 0;
}
